# DNA Comparison using Stack Final Project for CSPB2270

The data structure used in this project is a stack using a linked list. The stack implemented is to store individual bases in a single stranded DNA sequence where each base is a node in the stack. The stack was chosen because it maintains the order of the bases as they appear and will be read and compared in an ordered fashion to maintain the order of bases. The bases will then be read and removed in a last in, first out (LIFO) fashion. 


### Compiling and Running the Code

To compile and run the code, first clone the project from the GitHub repository then from the build directory from within the project, run cmake to create the necessary rules for running the files. 

Then run make to apply the rules to the correct executables. 

To run the code, run ./run_tests to compile the code and run the tests.
