#include <gtest/gtest.h>
#include "../code/DNAComp.h"

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>

using namespace std;

class test_DNAComp : public ::testing::Test {
protected:
	// This function runs only once before any TEST_F function
	static void SetUpTestCase(){
	}

	// This function runs after all TEST_F functions have been executed
	static void TearDownTestCase(){
	}
    
	// this function runs before every TEST_F function
	void SetUp() override {
    }

	// this function runs after every TEST_F function
	void TearDown() override {
	}
};

shared_ptr<Node> create_sequence(string A, string B, string C){
	shared_ptr<Node> top(new Node);
	top->base = A;
	top->next = shared_ptr<Node>(new Node);
	top->next->base = B;
	top->next->next = shared_ptr<Node>(new Node);
	top->next->next->base = C;
	top->next->next->next = shared_ptr<Node>(NULL);

	return top;
}

TEST_F(test_DNAComp, TestInitialization){
  DNAComp mylist;
  ASSERT_FALSE(mylist.GetTop());
}

TEST_F(test_DNAComp, TestPeek){
    DNAComp myDNA;
	shared_ptr<Node> seq = create_sequence("A", "T", "G");
	ASSERT_TRUE(seq);
    ASSERT_EQ("A",myDNA.peek(seq));
}

TEST_F(test_DNAComp, TestInsert){
    DNAComp myDNA;
    shared_ptr<Node> top = create_sequence("A", "T", "G");
	ASSERT_TRUE(top);
	myDNA.SetTop(top);

	myDNA.insert("C");
    ASSERT_EQ(myDNA.peek(top), top->base);
	
}

TEST_F(test_DNAComp, TestRemove){
    DNAComp myDNA;
	shared_ptr<Node> top = create_sequence("A", "T", "G");
	myDNA.SetTop(top);
	string gone = myDNA.remove(top);
    
    ASSERT_EQ("T", gone);

	gone = myDNA.remove(top);
	ASSERT_EQ("G", gone);

}

TEST_F(test_DNAComp, TestSize){
	DNAComp myDNA;
	
	shared_ptr<Node> top = create_sequence("A", "T", "G");
	myDNA.SetTop(top);
	ASSERT_EQ(3, myDNA.size(top));
}

TEST_F(test_DNAComp, TestPercentAlike){
	DNAComp myDNA;

	shared_ptr<Node> seq1 = create_sequence("A", "T", "G");
	shared_ptr<Node> seq2 = create_sequence("A", "T", "G");

	ASSERT_EQ(100,myDNA.PercentAlike(seq1, seq2));

}
