#include "DNAComp.h"

//Initialized the stack with an empty node named top
DNAComp::DNAComp(){
    shared_ptr<Node> top(new Node);
    top->base = "";
    top->next = shared_ptr<Node>(NULL);
}

//Deconstructor not needed due to use of shared_ptr
DNAComp::~DNAComp(){
    
}

shared_ptr<Node> DNAComp::newNode(){
    shared_ptr<Node> newNode(new Node);
    newNode->base = "";
    newNode->next = shared_ptr<Node>(NULL);
}

void DNAComp::insert(string base){
        shared_ptr<Node> node(new Node);
        node->base = base;
        node->next = top;
        top = node;
}

string DNAComp::remove(shared_ptr<Node> top){
    shared_ptr<Node> curr = top->next;
    if(curr->base != ""){
        top->base = curr->base;
        top->next = curr->next;
    } 
    return curr->base;
}

string DNAComp::peek(shared_ptr<Node> top){
    return top->base;

}

int DNAComp::PercentAlike(shared_ptr<Node> seq1, shared_ptr<Node> seq2){
    shared_ptr<Node> curr1 = seq1;
    shared_ptr<Node> curr2 = seq2;
    float numAlike = 0;

    while(curr1 != NULL && curr2 != NULL){
        if(curr1->base == curr2->base){
            numAlike = numAlike + 1;
        }
        curr1 = curr1->next;
        curr2 = curr2->next;
    }

    float percent = (numAlike / size(seq1)) * 100;
    return percent;
}

int DNAComp::size(shared_ptr<Node> top){
    shared_ptr<Node> curr = top;
    int total = 0;
    while(curr != NULL){
        total = total + 1;
        curr = curr->next;
    }
    return total;  
}

shared_ptr<Node> DNAComp::GetTop(){
    return top;
}

shared_ptr<Node> DNAComp::SetTop(shared_ptr<Node> top){
    top = top;
}