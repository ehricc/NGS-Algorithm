#ifndef DNACOMP_H__
#define DNACOMP_H__

#include <string>
#include <memory>

using namespace std;

//Node struct to allow for a greater allocation of different sized stacks.
struct Node{
  string base;
  shared_ptr<Node> next;
};

class DNAComp{
public:
  DNAComp();

  ~DNAComp();

  // This new function is to help to initialize new nodes.
  shared_ptr<Node> newNode();

  // This function will insert the base value provided into the top of the stack 
  void insert(string base);

  // This function will remove the top most base in a LIFO order.
  // Next base in the stack will then become the top most base.
  // The base will be read and compared before removal.
  string remove(shared_ptr<Node> top);


  // This function will peek at the top most element of the stack and return the value.
  string peek(shared_ptr<Node> top);

  // This will compare two sequences and return the percentage of how alike the sequences are to each other.
  int PercentAlike(shared_ptr<Node> seq1, shared_ptr<Node> seq2);


  // This will return the size of the sequence specified to know the amount of bases.
  int size(shared_ptr<Node> seq);

  //GetTop and SetTop are helper functions to the testing functions
  shared_ptr<Node> GetTop();
  
  shared_ptr<Node> SetTop(shared_ptr<Node> top);
    
private:
  shared_ptr<Node> top; //Indicates the pointer to the top of the stack
};

#endif // DNACOMP_H__